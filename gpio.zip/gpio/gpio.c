/******************************************************************************

 Copyright (C) 2020 THALES DIS AIS Deutschland GmbH

 This software is protected by international intellectual property laws and
 treaties. Customer shall not reverse engineer, decompile or disassemble the
 source code and shall only use the source code for the purpose of evaluation,
 analysis and to provide feedback thereon to Gemalto. Any right, title and
 interest in and to the source code, other than those expressly granted to the
 customer under this agreement, shall remain vested with Gemalto. This
 license may be terminated by Gemalto at any time in writing. Customer
 undertakes not to provide third parties with the source code. In particular,
 Customer is not allowed to sell, to lend or to license the source code or to
 make it available to the public.

 The information contained in this document is considered the CONFIDENTIAL and
 PROPRIETARY information of Gemalto M2M GmbH and may not be
 disclosed or discussed with anyone who is not employed by Gemalto M2M
 GmbH, unless the individual company:

 i)  has an express need to know such information, and

 ii) disclosure of information is subject to the terms of a duly executed
 Confidentiality  and Non-Disclosure Agreement between Gemalto M2M GmbH
 and the individual company.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 GEMALTO, ITS LEGAL REPRESENTATIVES AND VICARIOUS AGENTS SHALL - IRRESPECTIVE
 OF THE LEGAL GROUND - ONLY BE LIABLE FOR DAMAGES IF THE DAMAGE WAS CAUSED
 THROUGH CULPABLE BREACH OF A MAJOR CONTRACTUAL OBLIGATION (CARDINAL DUTY),
 I.E. A DUTY THE FULFILMENT OF WHICH ALLOWS THE PROPER EXECUTION OF THE
 RESPECTIVE AGREEMENT IN THE FIRST PLACE OR THE BREACH OF WHICH PUTS THE
 ACHIEVEMENT OF THE PURPOSE OF THE AGREEMENT AT STAKE, RESPECTIVELY, AND ON
 THE FULFILMENT OF WHICH THE RECIPIENT THEREFORE MAY RELY ON OR WAS CAUSED BY
 GROSS NEGLIGENCE OR INTENTIONALLY. ANY FURTHER LIABILITY FOR DAMAGES SHALL -
 IRRESPECTIVE OF THE LEGAL GROUND - BE EXCLUDED. IN THE EVENT THAT GEMALTO
 IS LIABLE FOR THE VIOLATION OF A MAJOR CONTRACTUAL OBLIGATION IN THE ABSENCE
 OF GROSS NEGLIGENCE OR WILFUL CONDUCT, SUCH LIABILITY FOR DAMAGE SHALL BE
 LIMITED TO AN EXTENT WHICH, AT THE TIME WHEN THE RESPECTIVE AGREEMENT IS
 CONCLUDED, GEMALTO SHOULD NORMALLY EXPECT TO ARISE DUE TO CIRCUMSTANCES THAT
 THE PARTIES HAD KNOWLEDGE OF AT SUCH POINT IN TIME. GEMALTO SHALL IN NO
 EVENT BE LIABLE FOR INDIRECT AND CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT.
 GEMALTO SHALL IN NO EVENT BE LIABLE FOR AN AMOUNT EXCEEDING EUR 20,000.00
 PER EVENT OF  DAMAGE. WITHIN THE BUSINESS RELATIONSHIP THE OVERALL LIABILITY
 SHALL BE  LIMITED TO A TOTAL OF EUR 100,000.00. CLAIMS FOR DAMAGES SHALL
 BECOME TIME-BARRED AFTER ONE YEAR AS OF THE BEGINNING OF THE STATUTORY
 LIMITATION PERIOD. IRRESPECTIVE OF THE LICENSEE'S KNOWLEDGE OR GROSS NEGLIGENT
 LACK OF  KNOWLEDGE OF THE CIRCUMSTANCES GIVING RISE FOR A LIABILITY ANY CLAIMS
 SHALL BECOME TIME-BARRED AFTER FIVE YEARS AS OF THE LIABILITY AROSE. THE
 AFOREMENTIONED LIMITATION OR EXCLUSION OF LIABILITY SHALL NOT APPLY IN THE
 CASE OF CULPABLE INJURY TO LIFE, BODY OR HEALTH, IN CASE OF INTENTIONAL ACTS,
 UNDER THE LIABILITY PROVISIONS OF THE GERMAN PRODUCT LIABILITY ACT
 (PRODUKTHAFTUNGSGESETZ) OR IN CASE OF A CONTRACTUALLY AGREED OBLIGATION TO
 ASSUME LIABILITY IRRESPECTIVE OF ANY FAULT (GUARANTEE).

 IN THE EVENT OF A CONFLICT BETWEEN THE PROVISIONS OF THIS AGREEMENT AND
 ANOTHER AGREEMENT REGARDING THE SOURCE CODE (EXCEPT THE GENERAL TERMS AND
 CONDITIONS OF GEMALTO) THE OTHER AGREEMENT SHALL PREVAIL.

 All rights created by patent grant or registration of a utility model or
 design patent are reserved.
******************************************************************************/

#include "gina.h"
#include "qapi_tlmm.h"
#include "qapi_timer.h"
#include "gpio_map.h"
#include "stdio.h"
#include "stdarg.h"
#include "string.h"

#include "qapi_fs.h" // for file system check

#ifdef PRODUCT_EXS_TX
GPIO_MAP gpio_mapping_table[] =
{
  {USER_GPIO1,28}, //DTR0
  {USER_GPIO2,27},   //DCD0
  {USER_GPIO3,3},    //DSR0
  {USER_GPIO4,26},   //
  {USER_GPIO5,9},    //LED - status
  {USER_GPIO6,11},
  {USER_GPIO7,10},
  {USER_GPIO8,8},
  {USER_GPIO16,12},  //RXD1
  {USER_GPIO17,13},  //TXD1
  {USER_GPIO18,14},  //RTS1/SPI_CS - share 
  {USER_GPIO19,15},  //CTS1/SPI_CLK - share
  {USER_GPIO20,23},  //TXDDAI
  {USER_GPIO21,22},  //RXDAI
  {USER_GPIO22,21},  //TFSDAI
  {USER_GPIO23,24},  //SCLK
  {USER_GPIO24,52},  //RING0 
  {USER_GPIO25,25},  //RING0
};
#else 
#ifdef PRODUCT_PLS
GPIO_MAP gpio_mapping_table[] =
{
  {USER_GPIO1,26},
  {USER_GPIO2,6},
  {USER_GPIO3,5},
  {USER_GPIO4,75},
  {USER_GPIO5,4},
  {USER_GPIO6,13},
  {USER_GPIO7,14},
  {USER_GPIO8,12},
  {USER_GPIO11,15},
  {USER_GPIO12,17},
  {USER_GPIO13,52},
  {USER_GPIO14,59},
  {USER_GPIO15,58},
  {USER_GPIO16,8},
  {USER_GPIO17,9},
  {USER_GPIO18,10},
  {USER_GPIO19,11},
  {USER_GPIO20,22},
  {USER_GPIO21,21},
  {USER_GPIO24,7},
  {USER_GPIO25,16},
  {USER_GPIO26,74},
};
#endif
#endif


/**
    Please see GPIO mapping table in gpio_map.h
*/ 


/**
    This define can be enabled to configure the GPIO as INPUT
    If not defined the GPIO is configued as OUTPUT
*/ 
//#define INPUT

#ifdef INPUT
qapi_GPIO_ID_t     gpio_id_in;
#else

qapi_GPIO_ID_t     gpio_id_out;
#endif


#ifdef INPUT
qapi_TLMM_Config_t tlmm_config_in;
#else
qapi_TLMM_Config_t tlmm_config_out;
#endif

/* cleanup used resources */
void cleanup(void * data)
{
  gina_cleanup();
  GINA_UWLOG_CRITICAL("cleanup: %s", (gchar *)data);
}


/******************************************************************************

DESCRIPTION
  GPIO initialisation to Output/Input
  Start periodical 5 s Timer zu toogle Output GPIO to High or Low or to read
  from Input GPIO

*******************************************************************************/
#ifdef USER_CODE
gstatus get_product_info(gchar* prodName);
void dam_app_gpio_test(void)
{
  qapi_Status_t  status = QAPI_OK;
  uint32_t       nLoopCounter = 0;
#ifdef INPUT
  qapi_GPIO_Value_t in_value = QAPI_GPIO_LOW_VALUE_E;
#else
static  qapi_GPIO_Value_t out_value = QAPI_GPIO_HIGH_VALUE_E;
#endif


#ifdef INPUT
  tlmm_config_in.pin = gpio_mapping_table[USER_GPIO7].nGpioNumber;
  tlmm_config_in.func = 1;
  tlmm_config_in.dir = QAPI_GPIO_INPUT_E;
  tlmm_config_in.pull = QAPI_GPIO_PULL_DOWN_E;
  tlmm_config_in.drive = QAPI_GPIO_2MA_E;
#else
  tlmm_config_out.pin = gpio_mapping_table[USER_GPIO4].nGpioNumber;
  tlmm_config_out.func = 0;
  tlmm_config_out.dir = QAPI_GPIO_OUTPUT_E;
  tlmm_config_out.pull= QAPI_GPIO_NO_PULL_E;
  tlmm_config_out.drive = QAPI_GPIO_2MA_E;
#endif

   /*Function to provide the client a ID as a token
     Note that clients should cache the ID*/
#ifdef INPUT
  status = qapi_TLMM_Get_Gpio_ID( &tlmm_config_in, &gpio_id_in);
  gina_uwlog_printf("Get ID: pin= %d  status = %d", gpio_id_in, status);
#else
  status = qapi_TLMM_Get_Gpio_ID( &tlmm_config_out, &gpio_id_out);
  gina_uwlog_printf("Get ID: pin= %d  status = %d", gpio_id_out, status);
#endif


  if (status == QAPI_OK)
  {
#ifdef INPUT
    //Configure GPIO
    status = qapi_TLMM_Config_Gpio(gpio_id_in, &tlmm_config_in);
    gina_uwlog_printf("Config: GPIO= %d  status = %d",tlmm_config_in.pin, status);
   //read GPIO
    qapi_TLMM_Read_Gpio(gpio_id_in,tlmm_config_in.pin,&in_value);
    gina_uwlog_printf("Read GPIO: %d  ",in_value);
#else
    //Configure GPIO
    status = qapi_TLMM_Config_Gpio(gpio_id_out, &tlmm_config_out);
    gina_uwlog_printf("Config: GPIO = %d  status = %d",tlmm_config_out.pin, status);
#endif

    while(1) //nLoopCounter++ < 20)
    {
      qapi_Timer_Sleep(800, QAPI_TIMER_UNIT_MSEC, true);
#ifdef INPUT
      //read GPIO
      status=qapi_TLMM_Read_Gpio(gpio_id_in,tlmm_config_in.pin,&in_value);
      gina_uwlog_printf("read GPIO: %d",in_value);
#else
      //toogle GPIO
      out_value=(out_value==QAPI_GPIO_LOW_VALUE_E)?QAPI_GPIO_HIGH_VALUE_E:QAPI_GPIO_LOW_VALUE_E;
      status=qapi_TLMM_Drive_Gpio(gpio_id_out,tlmm_config_out.pin,out_value);
      gina_uwlog_printf("set Level: %d",out_value);
#endif
    }



    //Release GPIO
#ifdef INPUT
    status = qapi_TLMM_Release_Gpio_ID( &tlmm_config_in, gpio_id_in);
    gina_uwlog_printf("status = %d", status);
#else
    status = qapi_TLMM_Release_Gpio_ID( &tlmm_config_out, gpio_id_out);
    gina_uwlog_printf("status = %d",  status);
#endif
  }
}
/******************************************************************************

DESCRIPTION
  main function to start gpio example



*******************************************************************************/

int _dam_main(void)
{
  gina_init();

  /* register the cleanup function */
  gina_uwmod_set_cleanup(cleanup, "MY CLEANUP");

  gina_uwlog_set_level(GINA_UWLOG_DBG);
  gina_uwlog_printf("GPIO - 5 test example");
  dam_app_gpio_test();
  return 0;
}
#endif
