#!/bin/sh
./build.sh
./signing.sh
cp ./build/signed/gpio.bin ../../../../../temp/SDK/tools/ocpp_script/ -f

