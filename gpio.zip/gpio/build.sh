#!/bin/sh
../../tools/linux/build.sh gpio $1 $2
