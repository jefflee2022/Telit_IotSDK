#!/bin/sh
./build.sh
./signing.sh
cp ./build/signed/mqtt.bin ../../../../../temp/SDK/tools/ocpp_script/ -f

