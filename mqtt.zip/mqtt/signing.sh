#!/bin/sh

python ../../tools/app.py sign --key ../../../../../1st_Cert/app_rot/app_rot.key ./build/mqtt.bin
