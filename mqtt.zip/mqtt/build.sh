#!/bin/sh
../../tools/linux/build.sh mqtt $1 $2
