/******************************************************************************

 Copyright (C) 2020 THALES DIS AIS Deutschland GmbH

 This software is protected by international intellectual property laws and
 treaties. Customer shall not reverse engineer, decompile or disassemble the
 source code and shall only use the source code for the purpose of evaluation,
 analysis and to provide feedback thereon to Gemalto. Any right, title and
 interest in and to the source code, other than those expressly granted to the
 customer under this agreement, shall remain vested with Gemalto. This
 license may be terminated by Gemalto at any time in writing. Customer
 undertakes not to provide third parties with the source code. In particular,
 Customer is not allowed to sell, to lend or to license the source code or to
 make it available to the public.

 The information contained in this document is considered the CONFIDENTIAL and
 PROPRIETARY information of Gemalto M2M GmbH and may not be
 disclosed or discussed with anyone who is not employed by Gemalto M2M
 GmbH, unless the individual company:

 i)  has an express need to know such information, and

 ii) disclosure of information is subject to the terms of a duly executed
 Confidentiality  and Non-Disclosure Agreement between Gemalto M2M GmbH
 and the individual company.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 GEMALTO, ITS LEGAL REPRESENTATIVES AND VICARIOUS AGENTS SHALL - IRRESPECTIVE
 OF THE LEGAL GROUND - ONLY BE LIABLE FOR DAMAGES IF THE DAMAGE WAS CAUSED
 THROUGH CULPABLE BREACH OF A MAJOR CONTRACTUAL OBLIGATION (CARDINAL DUTY),
 I.E. A DUTY THE FULFILMENT OF WHICH ALLOWS THE PROPER EXECUTION OF THE
 RESPECTIVE AGREEMENT IN THE FIRST PLACE OR THE BREACH OF WHICH PUTS THE
 ACHIEVEMENT OF THE PURPOSE OF THE AGREEMENT AT STAKE, RESPECTIVELY, AND ON
 THE FULFILMENT OF WHICH THE RECIPIENT THEREFORE MAY RELY ON OR WAS CAUSED BY
 GROSS NEGLIGENCE OR INTENTIONALLY. ANY FURTHER LIABILITY FOR DAMAGES SHALL -
 IRRESPECTIVE OF THE LEGAL GROUND - BE EXCLUDED. IN THE EVENT THAT GEMALTO
 IS LIABLE FOR THE VIOLATION OF A MAJOR CONTRACTUAL OBLIGATION IN THE ABSENCE
 OF GROSS NEGLIGENCE OR WILFUL CONDUCT, SUCH LIABILITY FOR DAMAGE SHALL BE
 LIMITED TO AN EXTENT WHICH, AT THE TIME WHEN THE RESPECTIVE AGREEMENT IS
 CONCLUDED, GEMALTO SHOULD NORMALLY EXPECT TO ARISE DUE TO CIRCUMSTANCES THAT
 THE PARTIES HAD KNOWLEDGE OF AT SUCH POINT IN TIME. GEMALTO SHALL IN NO
 EVENT BE LIABLE FOR INDIRECT AND CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT.
 GEMALTO SHALL IN NO EVENT BE LIABLE FOR AN AMOUNT EXCEEDING EUR 20,000.00
 PER EVENT OF  DAMAGE. WITHIN THE BUSINESS RELATIONSHIP THE OVERALL LIABILITY
 SHALL BE  LIMITED TO A TOTAL OF EUR 100,000.00. CLAIMS FOR DAMAGES SHALL
 BECOME TIME-BARRED AFTER ONE YEAR AS OF THE BEGINNING OF THE STATUTORY
 LIMITATION PERIOD. IRRESPECTIVE OF THE LICENSEE'S KNOWLEDGE OR GROSS NEGLIGENT
 LACK OF  KNOWLEDGE OF THE CIRCUMSTANCES GIVING RISE FOR A LIABILITY ANY CLAIMS
 SHALL BECOME TIME-BARRED AFTER FIVE YEARS AS OF THE LIABILITY AROSE. THE
 AFOREMENTIONED LIMITATION OR EXCLUSION OF LIABILITY SHALL NOT APPLY IN THE
 CASE OF CULPABLE INJURY TO LIFE, BODY OR HEALTH, IN CASE OF INTENTIONAL ACTS,
 UNDER THE LIABILITY PROVISIONS OF THE GERMAN PRODUCT LIABILITY ACT
 (PRODUKTHAFTUNGSGESETZ) OR IN CASE OF A CONTRACTUALLY AGREED OBLIGATION TO
 ASSUME LIABILITY IRRESPECTIVE OF ANY FAULT (GUARANTEE).

 IN THE EVENT OF A CONFLICT BETWEEN THE PROVISIONS OF THIS AGREEMENT AND
 ANOTHER AGREEMENT REGARDING THE SOURCE CODE (EXCEPT THE GENERAL TERMS AND
 CONDITIONS OF GEMALTO) THE OTHER AGREEMENT SHALL PREVAIL.

 All rights created by patent grant or registration of a utility model or
 design patent are reserved.
******************************************************************************/


#include "atCommand.h"

atcmd_t AT[2];

/* callback function for read data available
    Hndl: handle to AT instance
    data: user data, will be used to pass the wait event
    */
static void data_avail_cb(GinaIoHndl Hndl, void *data)
{
  /* set the wait flag */
  tx_event_flags_set((TX_EVENT_FLAGS_GROUP *)data, 1, TX_OR);
}

gstatus open_at(GinaAtcChannel channel, gchar *match, guint32 match_len)
{
	gstatus ret;
	gchar event_name[4] = "";
	memset(AT, 0, sizeof(AT));

	if ((channel > GINA_ATC2) || (AT[channel].gEvent != NULL))
	{
		GINA_UWLOG_ERROR("cannot open_at channel %i", channel);
		return GINA_ERROR;
	}
	/* open the channel */
	AT[channel].hdl = gina_atc_open(channel, &ret);
	if (ret != GINA_NOERROR)
	{
		GINA_UWLOG_ERROR("gina_atc_open: %u, %i", ret, AT[channel].hdl);
		return ret;
	}

	/* create a wait event */
	event_name[3] = channel;
	txm_module_object_allocate(&AT[channel].gEvent, sizeof(TX_EVENT_FLAGS_GROUP));
	tx_event_flags_create(AT[channel].gEvent, event_name);


	AT[channel].match = match;
	AT[channel].match_len = match_len;

	/*  Register a callback for read data available.
	  Please note, that you can only register one callback per AT channel!*/
	ret = gina_atc_ioctl(AT[channel].hdl, GINA_ATC_IOCTL_CB_REG, (void*)data_avail_cb, (void*)AT[channel].gEvent);
	if (ret != GINA_NOERROR)
	{
		GINA_UWLOG_ERROR("gina_atc_ioctl: %u", ret);
		tx_event_flags_delete(AT[channel].gEvent);
	}
	return ret;
}

void close_at(GinaAtcChannel channel)
{
	if ((channel > GINA_ATC2) || (AT[channel].gEvent == NULL))
	{
		GINA_UWLOG_ERROR("at channel %i not open", channel);
		return;
	}

	gina_atc_close(AT[channel].hdl);
	(void) gina_atc_ioctl(AT[channel].hdl, GINA_ATC_IOCTL_CB_UNREG, NULL, NULL);
	tx_event_flags_delete(AT[channel].gEvent);
	txm_module_object_deallocate(AT[channel].gEvent);
	AT[channel].gEvent = NULL;
}

gstatus read_at(GinaAtcChannel channel, gchar *expect, guint32 timeout)
{
	guint32 len;
	guint32 index;
	gstatus ret;
	ULONG set_signal = 0;

	len = 0;
	index = 0;

	if ((channel > GINA_ATC2) || (AT[channel].gEvent == NULL))
	{
		GINA_UWLOG_ERROR("read_at: cannot access channel %i", channel);
		return GINA_ERROR;
	}

	while (1)
	{
		/* wait until there is something to read */
		if (tx_event_flags_get(AT[channel].gEvent, 1, TX_OR_CLEAR, &set_signal, timeout) != TX_SUCCESS)
		{
			GINA_UWLOG_DBG("AT Receive %s", AT[channel].match);
			GINA_UWLOG_ERROR("Receiving timeout!");
			return GINA_ERROR;
		}
		/* try to fill the receive buffer */
		len = gina_atc_read(AT[channel].hdl, &AT[channel].match[index], AT[channel].match_len-index-1, &ret);
		if (ret != GINA_NOERROR)
		{
			GINA_UWLOG_ERROR("read: %u", ret);
			return GINA_ERROR;
		}
		index += len;
		/* terminate receive buffer with zero */
		AT[channel].match[index] = 0;
		/* try to match */
		if (strstr(AT[channel].match, expect) != NULL)
		{
			GINA_UWLOG_DBG("AT Receive %s", AT[channel].match);
			break;
		}
		if (AT[channel].match_len-index-1 == 0)
		{
			GINA_UWLOG_ERROR("match buffer overflow");
			return GINA_ERROR;
		}
	}
	return GINA_NOERROR;
}

gstatus send_at(GinaAtcChannel channel, gchar *cmd)
{
	guint32 len = strlen(cmd);
	guint32 written;
	gstatus ret;

	if ((channel > GINA_ATC2) || (AT[channel].gEvent == NULL))
	{
		GINA_UWLOG_ERROR("send_at cannot access channel %i", channel);
		return GINA_ERROR;
	}
	written = gina_atc_write(AT[channel].hdl, cmd, len, &ret);
	GINA_UWLOG_DBG("AT Send %s", cmd);
	if ((ret != GINA_NOERROR) || (written != len))
	{
		GINA_UWLOG_ERROR("gina_atc_write ret=%u, written=%u", ret, written);
		return GINA_ERROR;
	}
	return GINA_NOERROR;
}

gstatus send_at_conf(GinaAtcChannel channel, gchar *send, gchar *expect, guint32 timeout){
	
	gstatus ret;
	
	// Send AT command
	ret = send_at(channel, send);
	if(ret != GINA_NOERROR) return GINA_ERROR;
	
	/* Check for valid response */
	ret = read_at(channel, expect, timeout);
	if (ret != GINA_NOERROR) return GINA_ERROR;
	
	// Print response
	//GINA_UWLOG_INFO("%s", AT[channel].match);
	
	return GINA_NOERROR;
}



