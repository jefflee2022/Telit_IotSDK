/******************************************************************************

 Copyright (C) 2020 THALES DIS AIS Deutschland GmbH

 This software is protected by international intellectual property laws and
 treaties. Customer shall not reverse engineer, decompile or disassemble the
 source code and shall only use the source code for the purpose of evaluation,
 analysis and to provide feedback thereon to Gemalto. Any right, title and
 interest in and to the source code, other than those expressly granted to the
 customer under this agreement, shall remain vested with Gemalto. This
 license may be terminated by Gemalto at any time in writing. Customer
 undertakes not to provide third parties with the source code. In particular,
 Customer is not allowed to sell, to lend or to license the source code or to
 make it available to the public.

 The information contained in this document is considered the CONFIDENTIAL and
 PROPRIETARY information of Gemalto M2M GmbH and may not be
 disclosed or discussed with anyone who is not employed by Gemalto M2M
 GmbH, unless the individual company:

 i)  has an express need to know such information, and

 ii) disclosure of information is subject to the terms of a duly executed
 Confidentiality  and Non-Disclosure Agreement between Gemalto M2M GmbH
 and the individual company.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 GEMALTO, ITS LEGAL REPRESENTATIVES AND VICARIOUS AGENTS SHALL - IRRESPECTIVE
 OF THE LEGAL GROUND - ONLY BE LIABLE FOR DAMAGES IF THE DAMAGE WAS CAUSED
 THROUGH CULPABLE BREACH OF A MAJOR CONTRACTUAL OBLIGATION (CARDINAL DUTY),
 I.E. A DUTY THE FULFILMENT OF WHICH ALLOWS THE PROPER EXECUTION OF THE
 RESPECTIVE AGREEMENT IN THE FIRST PLACE OR THE BREACH OF WHICH PUTS THE
 ACHIEVEMENT OF THE PURPOSE OF THE AGREEMENT AT STAKE, RESPECTIVELY, AND ON
 THE FULFILMENT OF WHICH THE RECIPIENT THEREFORE MAY RELY ON OR WAS CAUSED BY
 GROSS NEGLIGENCE OR INTENTIONALLY. ANY FURTHER LIABILITY FOR DAMAGES SHALL -
 IRRESPECTIVE OF THE LEGAL GROUND - BE EXCLUDED. IN THE EVENT THAT GEMALTO
 IS LIABLE FOR THE VIOLATION OF A MAJOR CONTRACTUAL OBLIGATION IN THE ABSENCE
 OF GROSS NEGLIGENCE OR WILFUL CONDUCT, SUCH LIABILITY FOR DAMAGE SHALL BE
 LIMITED TO AN EXTENT WHICH, AT THE TIME WHEN THE RESPECTIVE AGREEMENT IS
 CONCLUDED, GEMALTO SHOULD NORMALLY EXPECT TO ARISE DUE TO CIRCUMSTANCES THAT
 THE PARTIES HAD KNOWLEDGE OF AT SUCH POINT IN TIME. GEMALTO SHALL IN NO
 EVENT BE LIABLE FOR INDIRECT AND CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT.
 GEMALTO SHALL IN NO EVENT BE LIABLE FOR AN AMOUNT EXCEEDING EUR 20,000.00
 PER EVENT OF  DAMAGE. WITHIN THE BUSINESS RELATIONSHIP THE OVERALL LIABILITY
 SHALL BE  LIMITED TO A TOTAL OF EUR 100,000.00. CLAIMS FOR DAMAGES SHALL
 BECOME TIME-BARRED AFTER ONE YEAR AS OF THE BEGINNING OF THE STATUTORY
 LIMITATION PERIOD. IRRESPECTIVE OF THE LICENSEE'S KNOWLEDGE OR GROSS NEGLIGENT
 LACK OF  KNOWLEDGE OF THE CIRCUMSTANCES GIVING RISE FOR A LIABILITY ANY CLAIMS
 SHALL BECOME TIME-BARRED AFTER FIVE YEARS AS OF THE LIABILITY AROSE. THE
 AFOREMENTIONED LIMITATION OR EXCLUSION OF LIABILITY SHALL NOT APPLY IN THE
 CASE OF CULPABLE INJURY TO LIFE, BODY OR HEALTH, IN CASE OF INTENTIONAL ACTS,
 UNDER THE LIABILITY PROVISIONS OF THE GERMAN PRODUCT LIABILITY ACT
 (PRODUKTHAFTUNGSGESETZ) OR IN CASE OF A CONTRACTUALLY AGREED OBLIGATION TO
 ASSUME LIABILITY IRRESPECTIVE OF ANY FAULT (GUARANTEE).

 IN THE EVENT OF A CONFLICT BETWEEN THE PROVISIONS OF THIS AGREEMENT AND
 ANOTHER AGREEMENT REGARDING THE SOURCE CODE (EXCEPT THE GENERAL TERMS AND
 CONDITIONS OF GEMALTO) THE OTHER AGREEMENT SHALL PREVAIL.

 All rights created by patent grant or registration of a utility model or
 design patent are reserved.
******************************************************************************/

#include "cellular.h"
#include "atCommand.h"
#include "gpio.h"

#define SMS_MAX_BUFFER_LENGTH 			20
#define SMS_MESSAGE_BUFFER_SIZE 		20
#define SMS_PHONE_NUMBER_BUFFER_SIZE	15

#define FS_BUFFER_CONFIG_FILE			128
#define FS_PHONE_LENGTH					15
#define FS_CONFIG_FILE					"/config.txt"

typedef struct
{
	guint32 index;
	gchar phone_number[SMS_PHONE_NUMBER_BUFFER_SIZE];
	gchar message[SMS_MESSAGE_BUFFER_SIZE];
} sms_t;

typedef struct{
	guint32 sms_index;
	sms_t sms[SMS_MAX_BUFFER_LENGTH];
} sms_buf_t;

typedef enum{
	CELLULAR_SMS_MCU,
	CELLULAR_SMS_EPAPP
} Cellular_Sms_device_type;

typedef enum{
	CELLULAR_SMS_RESET_MCU,
	CELLULAR_SMS_ALARM
} Cellular_Sms_action;

static sms_buf_t SMS;
static int Fd_ptr;
static gchar phone[16];

static void cellular_sms_init(void);
static gstatus cellular_sms_process(GinaAtcChannel channel);
static gstatus cellular_sms_copy_index(GinaAtcChannel channel);
static gstatus cellular_sms_send(GinaAtcChannel channel, gchar *phone, gchar *message);
static gstatus cellular_sms_clear_memory(GinaAtcChannel channel);
static gstatus cellular_sms_delete(guint32 index, GinaAtcChannel channel);
static gstatus cellular_sms_print();
static gstatus cellular_reset_MCU();

gstatus cellular_SMS_config(GinaAtcChannel channel){
	
	gstatus ret;
	
	cellular_sms_init();

	// Change SMS mode to text mode
	gchar cmd1[]="AT+CMGF=1\r";
	gchar rsp1[]="\r\nOK\r\n";
	ret = send_at_conf(channel, cmd1, rsp1, 1000);
	if(ret != GINA_NOERROR){
		GINA_UWLOG_ERROR("Enabling SMS text mode failed!");
		return GINA_ERROR;
	} 
	
	// clear SMS memory
	gchar cmd[]="AT^SMGL=\"REC UNREAD\"\r";
	gchar rsp[]="\r\nOK\r\n";
	ret = send_at_conf(channel, cmd, rsp, 1000);
	if(ret != GINA_NOERROR) return GINA_ERROR;
	
	cellular_sms_copy_index(channel);
	cellular_sms_clear_memory(channel);
	cellular_sms_init();
	
	GINA_UWLOG_INFO("Enabled SMS functionality successfully!");
	
	return GINA_NOERROR;
}

gstatus cellular_read_config(){
	
	qapi_FS_Status_t ret;
	char buffer[FS_BUFFER_CONFIG_FILE];
	uint32 bytes_read = 0;
	
	//Open config file
	ret = qapi_FS_Open(FS_CONFIG_FILE, QAPI_FS_O_RDWR_E, &Fd_ptr);
	if(ret != QAPI_OK){
		GINA_UWLOG_ERROR("Opening Config file failed! ERROR: %ld", ret);
		return GINA_ERROR;
	}
	
	//Read config file into buffer
	ret = qapi_FS_Read(Fd_ptr, buffer, FS_BUFFER_CONFIG_FILE-1, &bytes_read);
	if(ret != QAPI_OK){
		qapi_FS_Close(Fd_ptr);
		GINA_UWLOG_ERROR("Reading Config file failed! ERROR: %ld", ret);
		return GINA_ERROR;
	}
	
	// Copy phone number
	if(bytes_read <= FS_PHONE_LENGTH){
		strncpy(phone, buffer, bytes_read);
		GINA_UWLOG_INFO("Configured Phone number: %s", phone);
	}
	else{
		GINA_UWLOG_ERROR("Phone number in config file too long!");
		qapi_FS_Close(Fd_ptr);
		return GINA_ERROR;
	}
	// close file
	qapi_FS_Close(Fd_ptr);
	
	return GINA_NOERROR;
	
}

gstatus cellular_check_SMS(GinaAtcChannel channel){
	
	gstatus ret;
	
	// Request all unread SMS
	gchar cmd[]="AT^SMGL=\"REC UNREAD\"\r";
	gchar rsp[]="\r\nOK\r\n";
	ret = send_at_conf(channel, cmd, rsp, 1000);
	if(ret != GINA_NOERROR) return GINA_ERROR;

	// Copy SMS information into struct
	ret = cellular_sms_copy_index(channel);
	
	// Print detected unread messages
	cellular_sms_print();
		
	// Process the SMS content and decide if the SMS is dedicated for the EP application
	ret = cellular_sms_process(channel);
		
	// Clear sms buffer
	cellular_sms_init();

	return GINA_NOERROR;
}

gstatus cellular_check_SIM(GinaAtcChannel channel){
	
	gstatus ret;
	
	// Check if SIM card is inserted
	gchar cmd1[]="AT+CPIN?\r";
	gchar rsp1[]="READY";
	ret = send_at_conf(channel, cmd1, rsp1, 10);
	if(ret != GINA_NOERROR){
		GINA_UWLOG_ERROR("SIM card ERROR!");
		return GINA_ERROR;
	} 
	
	GINA_UWLOG_INFO("SIM card active!");
	
	return GINA_NOERROR;
	
}

gstatus cellular_alert(GinaAtcChannel channel){
	
	gstatus ret;
	GINA_UWLOG_INFO("Counter: %u", gpio_get_int_count());
	// check if interrupt got triggered, if triggered send SMS
	if(gpio_get_int_count() > 0){
		gpio_reset_int_count();
		gchar message[]="ALERT";
		ret = cellular_sms_send(channel, phone, message);
		if(ret != GINA_NOERROR){
			GINA_UWLOG_ERROR("SMS not sent!");
			return GINA_ERROR;
		} 	
		gina_uwlog_printf("Alert SMS sent!");
	}
	
	return GINA_NOERROR;
}

gstatus cellular_check_network_status(GinaAtcChannel channel){

	gstatus ret;
	gchar cmd1[]="AT^SMONI\r";
	gchar rsp1[]="Cat.M1";
	ret = send_at_conf(channel, cmd1, rsp1, 10);
	if(ret != GINA_NOERROR) return GINA_ERROR;
	
	return GINA_NOERROR;
	
}

/* init the SMS instance */
static void cellular_sms_init(void)
{
  memset(&SMS, 0, sizeof(SMS));
}


static gstatus cellular_sms_copy_index(GinaAtcChannel channel){
	
	guint32 index = 0;
	gchar buffer[2048];
	gchar buffer_or[2048];
	gchar *ptr;
	gchar delim[] = " ,\"\r\n";
	
	// check if buffer size is large enough
	if(strlen(AT[channel].match)+1 > 2048){
		GINA_UWLOG_ERROR("Too many messages to process, task skipped!");
		
		return GINA_ERROR;
	}
	
	//Copy entire string into temporary buffer
	memcpy(buffer, AT[channel].match, strlen(AT[channel].match)+1);
	
	// Find starting position in String (^SMGL:)
	ptr = strstr(buffer, "^SMGL:");
	
	if(ptr == NULL){
		GINA_UWLOG_INFO("No new messages!");
		return GINA_ERROR;
	}
	
	while(ptr != NULL){
		// Copy all unread 
		strcpy(buffer_or, ptr);
		// split string into substrings, each substring represents one short message (devider: ^SMGL:)
		// Skip ^SMGL
		ptr = strtok(ptr, delim);
		// Store SMS index
		ptr = strtok(NULL, delim);
		SMS.sms[index].index = atoi(ptr);
		// Skip REC UNREAD
		ptr = strtok(NULL, delim);
		ptr = strtok(NULL, delim);
		// Store phone number
		ptr = strtok(NULL, delim);
		memcpy(SMS.sms[index].phone_number, ptr, strlen(ptr));
		// Skip date and time
		ptr = strtok(NULL, delim);
		ptr = strtok(NULL, delim);
		//extract message
		ptr = strtok(NULL, delim);
		if(strlen(ptr) > strlen(SMS.sms[index].message)){
			memcpy(SMS.sms[index].message, ptr, SMS_MESSAGE_BUFFER_SIZE-1);
		}
		else{
			memcpy(SMS.sms[index].message, ptr, strlen(ptr)+1);
		}
		// Find next short message in the buffer
		strcpy(buffer, buffer_or);
		ptr = strstr(buffer+1, "^SMGL:");
		if(SMS.sms_index >= SMS_MAX_BUFFER_LENGTH){
			GINA_UWLOG_INFO("Too many SMS available, remaining messages will be processed next cycle!");
			return GINA_NOERROR;
		}
		SMS.sms_index++;
		index++;
	}
	
	return GINA_NOERROR;
}

static gstatus cellular_sms_process(GinaAtcChannel channel){
	
	gchar delim[] = ":";
	gchar *ptr;
	guint32 index = 0;
	gchar buffer[128];
	gstatus ret;
	
	while(index < SMS.sms_index){
		//Copy entire string into temporary buffer
		memcpy(buffer, SMS.sms[index].message, strlen(SMS.sms[index].message)+1);
		
		ptr = strtok(buffer, delim);
		// Leave SMS to MCU, SMS won't be deleted
		if(strcmp("MCU", ptr) == 0){
			GINA_UWLOG_INFO("SMS skipped as intended for MCU!");
		}
		// Process SMS content and delete SMS from module memory
		else if(strcmp("EP", ptr) == 0){
			cellular_sms_delete(index, channel);
			ptr = strtok(NULL, delim);
			if(strcmp("reset", ptr) == 0){
				if(cellular_reset_MCU() != GINA_NOERROR){
					GINA_UWLOG_ERROR("Reset failed!");
					return GINA_ERROR;
				}
				GINA_UWLOG_INFO("SMS processed!");
			}
		}
		// Don't process SMS, just delete
		else{
			GINA_UWLOG_INFO("SMS skipped as device type unknown!");
			cellular_sms_delete(index, channel);
		}
		index++;
	}
	return GINA_NOERROR;
}

static gstatus cellular_sms_send(GinaAtcChannel channel, gchar *phone, gchar *message){
	
	gstatus ret;
	gchar cmd[30];
	gchar rsp[30];
	
	sprintf(cmd, "AT+CMGS=\"%s\"\r", phone);
	strcpy(rsp,">");
	ret = send_at_conf(channel, cmd, rsp, 1000);
	if(ret == GINA_NOERROR){
		// Prepare message and terminate with 0x1A
		sprintf(cmd, "%s%s", message, "\x1A");
		strcpy(rsp,"\r\nOK\r\n");
		
		ret = send_at_conf(channel, cmd, rsp, 5000);
		if(ret != GINA_NOERROR){
			GINA_UWLOG_INFO("Sending SMS to %s failed", phone);
			return GINA_ERROR;
		}
	}
	else{
		GINA_UWLOG_INFO("Sending SMS to %s failed", phone);
	}
	
	return GINA_NOERROR;
}

static gstatus cellular_sms_clear_memory(GinaAtcChannel channel){
	
	guint32 index = 0;
	
	while(index < SMS.sms_index){
		cellular_sms_delete(SMS.sms[index].index, channel);
		index++;
	} 
	
	return GINA_NOERROR;
}

static gstatus cellular_sms_delete(guint32 index, GinaAtcChannel channel){
	
	gchar cmd[30];
	gstatus ret;
	
	sprintf(cmd, "AT+CMGD=%u\r", index);
	GINA_UWLOG_INFO("Delete SMS at index %u", index);
	gchar rsp[]="\r\nOK\r\n";
	ret = send_at_conf(channel, cmd, rsp, 1000);
	if(ret != GINA_NOERROR){
		GINA_UWLOG_ERROR("Deleting SMS at index %u failed", index)
		return GINA_ERROR;
	} 
	
	return GINA_NOERROR;
}

static gstatus cellular_sms_print(){
	
	guint32 index = 0;
	
	while(index < SMS.sms_index){
		gina_uwlog_printf("######################################################");
		gina_uwlog_printf("Incoming message %u:", index);
		gina_uwlog_printf("Index: %u", SMS.sms[index].index);
		gina_uwlog_printf("Phone Number: %s", SMS.sms[index].phone_number);
		gina_uwlog_printf("Message: %s", SMS.sms[index].message);
		gina_uwlog_printf("######################################################");
		index++;
	}
	
	return GINA_NOERROR;
}

static gstatus cellular_reset_MCU(){
	
	gstatus ret;
	
	ret = gpio_on();
	qapi_Timer_Sleep(2000, QAPI_TIMER_UNIT_MSEC, true);
	ret = gpio_off();
	
	return GINA_NOERROR;
}



