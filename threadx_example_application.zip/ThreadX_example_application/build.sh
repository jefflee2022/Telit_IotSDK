#!/bin/sh
../../tools/linux/build.sh helloworld
