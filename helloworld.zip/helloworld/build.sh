#!/bin/sh
../../tools/linux/build.sh helloworld $1 $2
