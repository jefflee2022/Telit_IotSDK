#!/bin/sh
./build.sh
./signing.sh
cp ./build/signed/helloworld.bin ../../../../../temp/SDK/tools/ocpp_script/ -f

