#!/bin/sh
../../tools/linux/build.sh comtcp $1 $2
