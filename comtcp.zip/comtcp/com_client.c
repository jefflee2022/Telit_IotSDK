/******************************************************************************

 Copyright (C) 2021 THALES DIS AIS Deutschland GmbH

 This software is protected by international intellectual property laws and
 treaties. Customer shall not reverse engineer, decompile or disassemble the
 source code and shall only use the source code for the purpose of evaluation,
 analysis and to provide feedback thereon to Gemalto. Any right, title and
 interest in and to the source code, other than those expressly granted to the
 customer under this agreement, shall remain vested with Gemalto. This
 license may be terminated by Gemalto at any time in writing. Customer
 undertakes not to provide third parties with the source code. In particular,
 Customer is not allowed to sell, to lend or to license the source code or to
 make it available to the public.

 The information contained in this document is considered the CONFIDENTIAL and
 PROPRIETARY information of Gemalto M2M GmbH and may not be
 disclosed or discussed with anyone who is not employed by Gemalto M2M
 GmbH, unless the individual company:

 i)  has an express need to know such information, and

 ii) disclosure of information is subject to the terms of a duly executed
 Confidentiality  and Non-Disclosure Agreement between Gemalto M2M GmbH
 and the individual company.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 GEMALTO, ITS LEGAL REPRESENTATIVES AND VICARIOUS AGENTS SHALL - IRRESPECTIVE
 OF THE LEGAL GROUND - ONLY BE LIABLE FOR DAMAGES IF THE DAMAGE WAS CAUSED
 THROUGH CULPABLE BREACH OF A MAJOR CONTRACTUAL OBLIGATION (CARDINAL DUTY),
 I.E. A DUTY THE FULFILMENT OF WHICH ALLOWS THE PROPER EXECUTION OF THE
 RESPECTIVE AGREEMENT IN THE FIRST PLACE OR THE BREACH OF WHICH PUTS THE
 ACHIEVEMENT OF THE PURPOSE OF THE AGREEMENT AT STAKE, RESPECTIVELY, AND ON
 THE FULFILMENT OF WHICH THE RECIPIENT THEREFORE MAY RELY ON OR WAS CAUSED BY
 GROSS NEGLIGENCE OR INTENTIONALLY. ANY FURTHER LIABILITY FOR DAMAGES SHALL -
 IRRESPECTIVE OF THE LEGAL GROUND - BE EXCLUDED. IN THE EVENT THAT GEMALTO
 IS LIABLE FOR THE VIOLATION OF A MAJOR CONTRACTUAL OBLIGATION IN THE ABSENCE
 OF GROSS NEGLIGENCE OR WILFUL CONDUCT, SUCH LIABILITY FOR DAMAGE SHALL BE
 LIMITED TO AN EXTENT WHICH, AT THE TIME WHEN THE RESPECTIVE AGREEMENT IS
 CONCLUDED, GEMALTO SHOULD NORMALLY EXPECT TO ARISE DUE TO CIRCUMSTANCES THAT
 THE PARTIES HAD KNOWLEDGE OF AT SUCH POINT IN TIME. GEMALTO SHALL IN NO
 EVENT BE LIABLE FOR INDIRECT AND CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT.
 GEMALTO SHALL IN NO EVENT BE LIABLE FOR AN AMOUNT EXCEEDING EUR 20,000.00
 PER EVENT OF  DAMAGE. WITHIN THE BUSINESS RELATIONSHIP THE OVERALL LIABILITY
 SHALL BE  LIMITED TO A TOTAL OF EUR 100,000.00. CLAIMS FOR DAMAGES SHALL
 BECOME TIME-BARRED AFTER ONE YEAR AS OF THE BEGINNING OF THE STATUTORY
 LIMITATION PERIOD. IRRESPECTIVE OF THE LICENSEE'S KNOWLEDGE OR GROSS NEGLIGENT
 LACK OF  KNOWLEDGE OF THE CIRCUMSTANCES GIVING RISE FOR A LIABILITY ANY CLAIMS
 SHALL BECOME TIME-BARRED AFTER FIVE YEARS AS OF THE LIABILITY AROSE. THE
 AFOREMENTIONED LIMITATION OR EXCLUSION OF LIABILITY SHALL NOT APPLY IN THE
 CASE OF CULPABLE INJURY TO LIFE, BODY OR HEALTH, IN CASE OF INTENTIONAL ACTS,
 UNDER THE LIABILITY PROVISIONS OF THE GERMAN PRODUCT LIABILITY ACT
 (PRODUKTHAFTUNGSGESETZ) OR IN CASE OF A CONTRACTUALLY AGREED OBLIGATION TO
 ASSUME LIABILITY IRRESPECTIVE OF ANY FAULT (GUARANTEE).

 IN THE EVENT OF A CONFLICT BETWEEN THE PROVISIONS OF THIS AGREEMENT AND
 ANOTHER AGREEMENT REGARDING THE SOURCE CODE (EXCEPT THE GENERAL TERMS AND
 CONDITIONS OF GEMALTO) THE OTHER AGREEMENT SHALL PREVAIL.

 All rights created by patent grant or registration of a utility model or
 design patent are reserved.
******************************************************************************/

/**
 * @brief  ASC0 COM port to a TCP server application
 * @version 1.1
 * @author Antony Shen <antony.shen@thalesgroup.com>
 */
#include "com_client.h"

configuration *psetup = NULL;

static serhndl_t ser_hndl;

static signed char netctrl_lib_status = NETCTRL_DSSLIB_STATE_CLOSED;
static qapi_DSS_Net_Evt_t netctrl_pdp_status = QAPI_DSS_EVT_INVALID_E;

static qapi_DSS_Hndl_t netctrl_dss_handle = NULL;
static TX_EVENT_FLAGS_GROUP *main_signal_hndl = NULL;

static TX_THREAD *tcp_client_main_workthread_hndl = NULL;
static char *tcp_client_main_workthread_stack = NULL;
static int tcp_sock_hndl = -1;
static tcp_threadinfo_t tcp_recvinfo;
static char ini_fname[] = "/comclient.ini";

static int netctrl_stop(void);

buffer_t *buffer_malloc(int size)
{
  buffer_t *pbuf = NULL;

  pbuf = bmalloc(sizeof(buffer_t));

  if (pbuf)
  {
    pbuf->buf = bmalloc(size);
    if (pbuf->buf)
    {
      pbuf->buf_size = size;
      pbuf->len = pbuf->offset = 0;
    }
  }

  return pbuf;
}

void buffer_free(buffer_t *pbuf)
{
  if (pbuf)
  {
    if (pbuf->buf)
    {
      bfree(pbuf->buf);
      pbuf->buf = NULL;
    }
    bfree(pbuf);
  }
}

int init_com_client()
{
  int rc = FALSE;

  if (psetup) bfree(psetup);

  if (!file_exist(ini_fname))
  {
    gina_uwlog_printf("== Create INI file: %s ==\n", ini_fname);
    create_ini_file(ini_fname);
  }
  psetup = get_config(ini_fname);

  if (psetup)
  {
    GINA_UWLOG_DBG("%s: Config loaded from string: baud=%d, ip=%s, port=%d, apn=%s, cid=%d, user=%s, pass=%s\n", __func__,
                   psetup->baud, psetup->tcp_server_ip, psetup->tcp_server_port, psetup->apn, psetup->apn_cid, psetup->apn_username, psetup->apn_passwd);
    rc = TRUE;
  }

  return rc;
}

static int ser_uart_close(GinaIoHndl *Hndl)
{
  gstatus err = gina_serdev_close(*Hndl);
  GINA_UWLOG_INFO("gina_serdev_close hndl=%08x rc=%d", *Hndl, err);

  if (err == GINA_NOERROR)
  {
    *Hndl = -1;
  }

  return err == GINA_NOERROR ? 0 : -1;
}

/* cleanup used resources */
void release_com_client_resources()
{
  if (main_signal_hndl != NULL)
  {
    tx_event_flags_delete(main_signal_hndl);
    txm_module_object_deallocate(main_signal_hndl);
  }

  if (ser_hndl.serHndl >= 0)
  {
    ser_uart_close(&ser_hndl.serHndl);
    if (ser_hndl.buffer)
    {
      buffer_free(ser_hndl.buffer);
      ser_hndl.buffer = NULL;
    }
  }

  if (tcp_client_main_workthread_hndl != NULL)
    txm_module_object_deallocate(tcp_client_main_workthread_hndl);

  if (tcp_client_main_workthread_stack)
    bfree(tcp_client_main_workthread_stack);
  
  if (psetup) {
    bfree(psetup);
    psetup = NULL;
  }
}

static gint32 tcp_client_send()
{
  gint32 ret = 0, total = 0;

  while (ser_hndl.buffer->len > 0)
  {
    ret = qapi_send(tcp_sock_hndl, ser_hndl.buffer->buf + ser_hndl.buffer->offset, ser_hndl.buffer->len, 0);
    GINA_UWLOG_INFO("tcp_client_send: send fd=%d len=%d sent=%d",
                    tcp_sock_hndl, ser_hndl.buffer->len, ret);

    if (ret < 0)
    {
      int err = qapi_errno(tcp_sock_hndl);
      if (err != EWOULDBLOCK)
      {
        GINA_UWLOG_ERROR("tcp_client_send: send error=%d", err);
        break;
      }
    }
    else
    {
      total += ret;
      ser_hndl.buffer->len -= ret;
      if (ser_hndl.buffer->len)
        ser_hndl.buffer->offset += ret;
      else
        ser_hndl.buffer->offset = 0;
    }
  }

  return total;
}

static gint32 ser_write(buffer_t *pbuf)
{
  gint32 len = 0, total = 0, err;
  while (pbuf->len)
  {
    pbuf->len += len;

    len = gina_serdev_write(ser_hndl.serHndl, pbuf->buf + pbuf->offset, pbuf->len, &err);
    if (err == GINA_NOERROR)
    {
      pbuf->len -= len;
      pbuf->offset = (pbuf->len) ? pbuf->offset += len : 0;
      total += len;
    }
    else
    {
      GINA_UWLOG_INFO("write error %d", err);
    }
  }

  return total;
}

static void ser_event_cb(
    int32 Hndl,
    void *user_value,
    GinaSerdev_cb_events event,
    int32 value)
{
  int inst = -1;
  int peer;

  gstatus err;
  gint32 len;

  if (Hndl != ser_hndl.serHndl)
  {
    GINA_UWLOG_ERROR("INVALID HNDL=0x%lx", Hndl);
    return;
  }

  switch (event)
  {
  case GINA_SERDEV_CB_DATA_AVAILABLE:
#if DEBUG_SIGNALS > 1
    GINA_UWLOG_INFO("DATA AVAIL on hndl #%d", inst);
#endif
    len = gina_serdev_read(Hndl, ser_hndl.buffer->buf + ser_hndl.buffer->offset, ser_hndl.buffer->buf_size - ser_hndl.buffer->offset, &err);

    if (err == GINA_NOERROR)
    {
      if (len)
      {
        ser_hndl.buffer->len += len;
        tcp_client_send();
      }
    }
    else
    {
      GINA_UWLOG_INFO("read error %d", err);
    }
    break;

  case GINA_SERDEV_CB_TX_ENABLED:
#if DEBUG_SIGNALS > 1
    GINA_UWLOG_INFO("TX ENABLED on hndl #%d", inst);
#endif
    ser_write(tcp_recvinfo.buffer);
    break;

  case GINA_SERDEV_CB_DTR_TOGGLED:
#if DEBUG_SIGNALS > 0
    GINA_UWLOG_INFO("DTR toggle found on hndl #%ld, val=%d", Hndl, (int)value);
#endif
#ifdef TOGGLE_DTR_TO_CLOSE
    GINA_UWLOG_INFO("close application now");
    tx_event_flags_set(main_signal_hndl, SER_CLOSE_EVENT, TX_OR);
#endif
    break;
  }
}

static int ser_uart_open(GinaSerDev TheDevice, GinaIoHndl *Hndl)
{
#if DEBUG_SIGNALS > 0
  char SendText[256];
#endif
  gstatus err;
  int Len, sent;
  GinaSerialOpenParam props;

  memset(&props, 0, sizeof(props));

  props.baudrate = psetup->baud;
  props.CharFraming = SER_CHAR_FRAME;
  props.flow_rx =
      props.flow_tx = SER_FLOW_CTRL;

  *Hndl = gina_serdev_open(TheDevice, &props, &err);
  GINA_UWLOG_INFO("gina_serdev_open dev=%d hndl=%d rc=%d", (int)TheDevice, *Hndl, err);

  if ((err != GINA_NOERROR) || (*Hndl < 0))
  {
    return -1;
  }

  /** set our main callback for all events */
  err = gina_serdev_ioctl(*Hndl,
                          GINA_SERDEV_IOCTL_CB_REG,
                          (void *)ser_event_cb, Hndl);
  GINA_UWLOG_INFO("gina_serdev_ioctl(CB_REG) rc=%d", err);

  if (err != GINA_NOERROR)
  {
    return -1;
  }

#if DEBUG_SIGNALS > 0
  Len = snprintf(SendText, sizeof(SendText),
                 "\r\n"
                 "GINA_SERDEV EXAMPLE\r\n"
                 "This is device=%d, hndl=0x%08x, baud=%d (valid on ASC only)\r\n"
                 "data will be looped on the interface\r\n"
#ifdef TOGGLE_DTR_TO_CLOSE
                 "close this application with a DTR toggle at any opened interface\r\n"
#endif
                 "\r\n",
                 TheDevice, *Hndl, props.baudrate);
#endif

  return 0;
}

static int ser_init(void)
{
  ULONG status = TX_NO_INSTANCE;

  memset(&ser_hndl, 0x00, sizeof(serhndl_t));

  /** init first device */
  if (ser_uart_open(GINA_SERDEV_ASC_CHANNEL_0, &ser_hndl.serHndl) < 0)
  {
    GINA_UWLOG_ERROR("could not open ASC0 interface");
  }
  else
  {
    status = (ser_hndl.buffer = buffer_malloc(SIZE_SER_BUF)) ? TX_SUCCESS : TX_NO_MEMORY;
  }

  return status;
}

static void tcp_recvthread(ULONG param)
{
  int ret;

  tcp_threadinfo_t *info = (tcp_threadinfo_t *)param;
  int32 sig_mask = SER_CLOSE_EVENT;
  ULONG ser_event = 0, status;

  while (info->hostname)
  {
    fd_set rset;
    int32_t recvd;

    qapi_fd_zero(&rset);
    qapi_fd_set(info->sock_fd, &rset);
    ret = qapi_select(&rset, NULL, NULL, 1000);

    if (ret <= 0)
    {
      if (qapi_errno(info->sock_fd))
      {
        GINA_UWLOG_ERROR("tcp_recvthread: select error=%d",
                         qapi_errno(info->sock_fd));
        break;
      }
    }

    if (1 == qapi_fd_isset(info->sock_fd, &rset))
    {
      recvd = qapi_recv(info->sock_fd, info->buffer->buf, info->buffer->buf_size, 0);

      if (recvd == 0)
      {
        GINA_UWLOG_INFO("tcp_recvthread: FIN found");
        break;
      }
      else if (recvd < 0)
      {
        GINA_UWLOG_ERROR("tcp_recvthread: recv error=%d",
                         qapi_errno(info->sock_fd));
        break;
      }
      else
      {
        info->buffer->len += recvd;
        ser_write(info->buffer);
      }
    }

    /* main signal process */
    status = tx_event_flags_get(main_signal_hndl,
                                sig_mask, TX_OR_CLEAR,
                                &ser_event, TX_NO_WAIT);

    if (ser_event & SER_CLOSE_EVENT)
    {
      GINA_UWLOG_INFO("ASC0 DTR Toggled! STOP Signal!");
      break;
    }
  }

  ret = tx_event_flags_set(info->flags_group, info->flag, TX_OR);
  if (ret != TX_SUCCESS)
  {
    GINA_UWLOG_ERROR("tcp_recvthread: could not flag main thread, rc=%d",
                     ret);
  }

  GINA_UWLOG_HIGH("tcp_recvthread: STOP");
  tx_thread_terminate(tx_thread_identify());
}

static void tcp_client_main_workthread(ULONG param)
{
  struct sockaddr_in server_addr;
  int ret, errno = 0, sock_ds = -1;

  GINA_UWLOG_INFO("tcpclient: START");

  do
  {
    qapi_Status_t rc;

    /** create socket */
    sock_ds = qapi_socket(AF_INET, SOCK_STREAM, 0);
    GINA_UWLOG_INFO("tcpclient: create socket fd=%d", sock_ds);

    if (sock_ds < 0)
      break;

    server_addr.sin_family = AF_INET;
    server_addr.sin_port = _htons(psetup->tcp_server_port);
    server_addr.sin_addr.s_addr = inet_addr(psetup->tcp_server_ip);

    GINA_UWLOG_INFO("tcpclient: connecting");
    rc = qapi_connect(sock_ds, (struct sockaddr *)&server_addr,
                      sizeof(server_addr));

    if (rc == 0)
    {
      GINA_UWLOG_INFO("tcpclient: connected");
    }
    else
    {
      errno = qapi_errno(sock_ds);
      GINA_UWLOG_ERROR("tcpclient: failed with error=%d", errno);
      break;
    }

    rc = qapi_setsockopt(sock_ds, SOL_SOCKET, SO_NBIO, NULL, 0);
    GINA_UWLOG_INFO("tcpclient: set nonblocking mode rc=%d", rc);

    if (rc == QAPI_OK)
    {
      int status, fullflags = 0;

      TX_THREAD *tcp_recvthread_hndl;
      char *tcp_recvthread_stack;

      TX_EVENT_FLAGS_GROUP *finish_signal_hndl;

      status = txm_module_object_allocate(&finish_signal_hndl,
                                          sizeof(TX_EVENT_FLAGS_GROUP));
      if (TX_SUCCESS != status)
      {
        GINA_UWLOG_ERROR("tcpclient: cannot allocate flags_group");
        break;
      }

      status = tx_event_flags_create(finish_signal_hndl,
                                     "fsignal_hndl");
      if (TX_SUCCESS != status)
      {
        GINA_UWLOG_ERROR("tcpclient: cannot create flags_group");
        break;
      }

      /** get the memory for the threads */
      status = txm_module_object_allocate((VOID *)&tcp_recvthread_hndl,
                                          sizeof(TX_THREAD));

      if ((status != TX_SUCCESS))
      {
        GINA_UWLOG_ERROR("tcpclient: threads alloc failed rc=%d",
                         status);
        break;
      }

      tcp_recvthread_stack = (char *)bmalloc(SOCK_THREAD_STACK_SIZE);

      if (!tcp_recvthread_stack)
      {
        GINA_UWLOG_ERROR("tcpclient: threads stack alloc failed");
        break;
      }

      tcp_recvinfo.flags_group = finish_signal_hndl;
      tcp_recvinfo.sock_fd = sock_ds;
      tcp_recvinfo.hostname = psetup->tcp_server_ip;
      tcp_recvinfo.flag = 0x0002;
      tcp_recvinfo.buffer = buffer_malloc(SIZE_SER_BUF);

      status = tx_thread_create(tcp_recvthread_hndl,
                                "threadRcv", tcp_recvthread,
                                (void *)&tcp_recvinfo, tcp_recvthread_stack,
                                SOCK_THREAD_STACK_SIZE,
                                SOCK_THREAD_PRIORITY,
                                SOCK_THREAD_PRIORITY,
                                TX_NO_TIME_SLICE,
                                TX_AUTO_START);

      if ((status != TX_SUCCESS))
      {
        GINA_UWLOG_ERROR("tcpclient: threads creation failed rc=%d",
                         status);
        break;
      }

      tcp_sock_hndl = sock_ds;

      //~ enable ASC0 I/O
      ser_init();

      while (fullflags != (tcp_recvinfo.flag))
      {
        int dss_event = 0, sig_mask = tcp_recvinfo.flag;

        status = tx_event_flags_get(finish_signal_hndl, sig_mask,
                                    TX_OR_CLEAR, &dss_event,
                                    TX_WAIT_FOREVER);
        GINA_UWLOG_INFO("tcpclient: recv event=0x%x rc=%d",
                        dss_event, status);
        fullflags |= dss_event;
      }

      GINA_UWLOG_HIGH("tcpclient: all events found; finish now");
      tx_event_flags_delete(finish_signal_hndl);
      txm_module_object_deallocate(finish_signal_hndl);

      while (TX_DELETE_ERROR == tx_thread_delete(tcp_recvthread_hndl))
        qapi_Timer_Sleep(100, QAPI_TIMER_UNIT_MSEC, true);

      buffer_free(tcp_recvinfo.buffer);

      txm_module_object_deallocate((VOID *)tcp_recvthread_hndl);
      bfree(tcp_recvthread_stack);
    }
  } while (0);

  if (sock_ds >= 0)
  {
    qapi_socketclose(sock_ds);
  }

  ret = tx_event_flags_set(main_signal_hndl,
                           NETCTRL_SIG_EVT_FINISHED_EVENT,
                           TX_OR);
  if (ret != TX_SUCCESS)
  {
    GINA_UWLOG_ERROR("tcpclient: could not flag main thread, rc=%d", ret);
  }

  GINA_UWLOG_HIGH("tcpclient: STOP");
  tx_thread_terminate(tx_thread_identify());
}

static void netctrl_event_cb(
    qapi_DSS_Hndl_t hndl,
    void *user_data,
    qapi_DSS_Net_Evt_t evt,
    qapi_DSS_Evt_Payload_t *payload_ptr)
{
  /*****************************
   ATTENTION: DO NOT CALL ANY
   GINA/QAPI FUNCTIONS CAUSE THEY
   USUALLY RUN INTO A SYSCALL
   NOT POSSIBLE HERE
   *****************************/

  qapi_Status_t status = QAPI_OK;

  switch (evt)
  {
  case QAPI_DSS_EVT_NET_IS_CONN_E:
    //** datacall connected */;
    netctrl_pdp_status = QAPI_DSS_EVT_NET_IS_CONN_E;
    tx_event_flags_set(main_signal_hndl,
                       NETCTRL_SIG_EVT_CONNECTED_EVENT,
                       TX_OR);
    break;

  case QAPI_DSS_EVT_NET_NO_NET_E:
    if (QAPI_DSS_EVT_NET_IS_CONN_E == netctrl_pdp_status)
    {
      tx_event_flags_set(main_signal_hndl,
                         NETCTRL_SIG_EVT_EXIT_EVENT,
                         TX_OR);
    }
    else
    {
      tx_event_flags_set(main_signal_hndl,
                         NETCTRL_SIG_EVT_NOCONN_EVENT,
                         TX_OR);
    }
    break;

  default:
    /* Signal main task */
    tx_event_flags_set(main_signal_hndl,
                       NETCTRL_SIG_EVT_INVALID_EVENT,
                       TX_OR);
    break;
  }
}

static void netctrl_printInfo(void)
{
  unsigned int i, j, len;
  qapi_Status_t status;
  qapi_DSS_Addr_Info_t info_ptr[TEST_NUM_ADDRS];

  status = qapi_DSS_Get_IP_Addr_Count(netctrl_dss_handle, &len);
  GINA_UWLOG_INFO("qapi_DSS_Get_IP_Addr_Count rc=%d", status);
  if (QAPI_ERROR == status)
    return;

  status = qapi_DSS_Get_IP_Addr(netctrl_dss_handle, info_ptr, len);
  GINA_UWLOG_INFO("qapi_DSS_Get_IP_Addr rc=%d", status);
  if (QAPI_ERROR == status)
    return;

  j = GET_ADDR_INFO_MIN(len, TEST_NUM_ADDRS);

  for (i = 0; i < j; i++)
  {
    if (info_ptr[i].iface_addr_s.valid_addr)
    {
      char addr_v4[16];
      GINA_UWLOG_INFO("IP     addr: %s",
                      inet_ntop(AF_INET, &info_ptr[i].iface_addr_s.addr, addr_v4,
                                sizeof(addr_v4)));
      GINA_UWLOG_INFO("  GW   addr: %s",
                      inet_ntop(AF_INET, &info_ptr[i].gtwy_addr_s.addr, addr_v4,
                                sizeof(addr_v4)));
      GINA_UWLOG_INFO("  DNS1 addr: %s",
                      inet_ntop(AF_INET, &info_ptr[i].dnsp_addr_s.addr, addr_v4,
                                sizeof(addr_v4)));
      GINA_UWLOG_INFO("  DNS2 addr: %s",
                      inet_ntop(AF_INET, &info_ptr[i].dnss_addr_s.addr, addr_v4,
                                sizeof(addr_v4)));
    }
  }
}

static int netctrl_SetPDPParams(int IpVer)
{
  qapi_Status_t rc;
  qapi_DSS_Call_Param_Value_t param_info;

  if (NULL == netctrl_dss_handle)
  {

    GINA_UWLOG_INFO("Dss handler is NULL!!!");
    return -1;
  }

  /* set data call param */
  param_info.buf_val = NULL;
  param_info.num_val = QAPI_DSS_RADIO_TECH_UNKNOWN;
  rc = qapi_DSS_Set_Data_Call_Param(netctrl_dss_handle,
                                    QAPI_DSS_CALL_INFO_TECH_PREF_E,
                                    &param_info);
  GINA_UWLOG_INFO("Set TECH_PREF to AUTO, rc=%d", rc);

  /* set apn */
  param_info.buf_val = psetup->apn;
  param_info.num_val = strlen(psetup->apn);
  rc = qapi_DSS_Set_Data_Call_Param(netctrl_dss_handle,
                                    QAPI_DSS_CALL_INFO_APN_NAME_E,
                                    &param_info);
  GINA_UWLOG_INFO("Set APN=%s, rc=%d", psetup->apn, rc);

  /* set apn username */
  if (psetup->apn_username &&  strlen(psetup->apn_username))
  {
    param_info.buf_val = psetup->apn_username;
    param_info.num_val = strlen(psetup->apn_username);
    rc = qapi_DSS_Set_Data_Call_Param(netctrl_dss_handle,
                                      QAPI_DSS_CALL_INFO_USERNAME_E,
                                      &param_info);
    GINA_UWLOG_INFO("Set APN_USER=%s, rc=%d", psetup->apn_username, rc);
  }

  /* set apn password */
  if (psetup->apn_passwd && strlen(psetup->apn_passwd))
  {
    param_info.buf_val = psetup->apn_passwd;
    param_info.num_val = strlen(psetup->apn_passwd);
    rc = qapi_DSS_Set_Data_Call_Param(netctrl_dss_handle,
                                      QAPI_DSS_CALL_INFO_PASSWORD_E,
                                      &param_info);
    GINA_UWLOG_INFO("Set APN_PASSWORD=%s, rc=%d", psetup->apn_passwd, rc);
  }

  /* set IP version(IPv4 or IPv6) */
  param_info.buf_val = NULL;
  param_info.num_val = IpVer;
  rc = qapi_DSS_Set_Data_Call_Param(netctrl_dss_handle,
                                    QAPI_DSS_CALL_INFO_IP_VERSION_E,
                                    &param_info);
  GINA_UWLOG_INFO("Set IP_family=IPv%d, rc=%d", param_info.num_val, rc);

  /**
        depending from the used network, not every +CGDCONT position is usable
        from DAM application.

        Often, 1-4 is used internally by the modem, and the
        customer has to use 5++

        Sometimes (i.e. Verizon) the usage of a dedicated APN index + name is
        dedicated.

        PLEASE NOTE:
        The contexct has to exist!
        Please add this context (once, persitent) with
          AT+CGDCONT=<ProfileIdx>,<IpVer>,<APN>
        with the correct values before using it.

        The IPV4 example use the default context on Idx 1 for a connection.
    */
  param_info.buf_val = NULL;
  param_info.num_val = psetup->apn_cid;
  rc = qapi_DSS_Set_Data_Call_Param(netctrl_dss_handle,
                                    QAPI_DSS_CALL_INFO_UMTS_PROFILE_IDX_E,
                                    &param_info);
  GINA_UWLOG_INFO("Set UMTS_PROFILE_IDX=%d, rc=%d",
                  param_info.num_val, rc);

  /**
        we currently ignore any error; for a product,
        this is not the best idea
    */
  return 0;
}

/* Initializes the DSS netctrl library for the specified operating mode */
static int netctrl_init(void)
{
  int ret_val = 0;
  qapi_Status_t status = QAPI_OK;

  /* Initializes the DSS netctrl library */
  if (QAPI_OK == qapi_DSS_Init(QAPI_DSS_MODE_GENERAL))
  {
    netctrl_lib_status = NETCTRL_DSSLIB_STATE_OPENED;
    GINA_UWLOG_INFO("qapi_DSS_Init() success");
  }
  else
  {
    /* @Note: netctrl library has been initialized */
    netctrl_lib_status = NETCTRL_DSSLIB_STATE_FAILED;
    GINA_UWLOG_INFO("qapi_DSS_Init() failed; continue anyway \
                         (already initialized?)");
  }

  /* Registering callback */
  do
  {
    GINA_UWLOG_INFO("Registering Callback dss handle");

    status = qapi_DSS_Get_Data_Srvc_Hndl(netctrl_event_cb,
                                         NULL,
                                         &netctrl_dss_handle);
    GINA_UWLOG_INFO("dss handle=%p, status=%d, %s",
                    netctrl_dss_handle, status,
                    NULL == netctrl_dss_handle ? "FAIL, RETRY" : "SUCCESS");

    if (NULL != netctrl_dss_handle)
    {
      GINA_UWLOG_INFO("Registed netctrl_dss_handler success");
      break;
    }

    /* retry each 100 ms */
    qapi_Timer_Sleep(100, QAPI_TIMER_UNIT_MSEC, true);
  } while (1);

  return ret_val;
}

static int netctrl_start(void)
{
  int rc = 0;

  if (0 == netctrl_init())
  {
    /* Get valid DSS handler and set the data call parameter */
    netctrl_SetPDPParams(QAPI_DSS_IP_VERSION_4);

    GINA_UWLOG_INFO("qapi_DSS_Start_Data_Call start!!!");
    if (QAPI_OK == qapi_DSS_Start_Data_Call(netctrl_dss_handle))
    {
      GINA_UWLOG_INFO("Start Data service success");
    }
    else
    {
      rc = -1;
    }
  }
  else
  {
    GINA_UWLOG_INFO("dss_init fail");
    rc = -1;
  }
  return rc;
}

static int netctrl_stop(void)
{
  qapi_Status_t status;

  if (netctrl_dss_handle)
  {
    status = qapi_DSS_Stop_Data_Call(netctrl_dss_handle);
    GINA_UWLOG_INFO("Stop data call, rc=%d", status);

    status = qapi_DSS_Rel_Data_Srvc_Hndl(netctrl_dss_handle);
    GINA_UWLOG_INFO("Release dss handle, rc=%d", status);
  }

  status = qapi_DSS_Release(QAPI_DSS_MODE_GENERAL);
  GINA_UWLOG_INFO("netctrl_stop: qapi_DSS_Release(), rc=%d", status);
  return 0;
}

int com_client(void)
{
  ULONG dss_event = 0;
  int32 sig_mask;
  ULONG status;

  /* Create event signal handle and clear signals */
  status = txm_module_object_allocate(&main_signal_hndl,
                                      sizeof(TX_EVENT_FLAGS_GROUP));
  GINA_UWLOG_INFO("allocate event rc=%lu", status);
  if (TX_SUCCESS != status)
    return -1;

  status = tx_event_flags_create(main_signal_hndl, "main_signal_hndl");
  GINA_UWLOG_INFO("create event rc=%lu", status);
  if (TX_SUCCESS != status)
    return -1;

  netctrl_start();

  sig_mask = NETCTRL_SIG_EVT_INVALID_EVENT |
             NETCTRL_SIG_EVT_NOCONN_EVENT |
             NETCTRL_SIG_EVT_CONNECTED_EVENT |
             NETCTRL_SIG_EVT_FINISHED_EVENT |
             NETCTRL_SIG_EVT_EXIT_EVENT;

  while (1)
  {
    /* main signal process */
    status = tx_event_flags_get(main_signal_hndl,
                                sig_mask, TX_OR_CLEAR,
                                &dss_event, TX_WAIT_FOREVER);
    GINA_UWLOG_INFO("main: got event=0x%lx status=%lu",
                    dss_event, status);

    if (dss_event & NETCTRL_SIG_EVT_INVALID_EVENT)
    {
      GINA_UWLOG_INFO("NETCTRL_SIG_EVT_INVALID_EVENT Signal");
    }
    if (dss_event & NETCTRL_SIG_EVT_NOCONN_EVENT)
    {
      GINA_UWLOG_INFO("NETCTRL_SIG_EVT_NOCONN_EVENT Signal");
    }
    if (dss_event & NETCTRL_SIG_EVT_CONNECTED_EVENT)
    {
      GINA_UWLOG_INFO("NETCTRL_SIG_EVT_CONNECTED_EVENT Signal");

      netctrl_printInfo();

      /** get the memory for the test thread */
      if (TX_SUCCESS != txm_module_object_allocate(
                            (VOID *)&tcp_client_main_workthread_hndl,
                            sizeof(TX_THREAD)))
      {
        GINA_UWLOG_INFO("COM Client Workthread thread alloc failed");
        break;
      }

      tcp_client_main_workthread_stack =
          (char *)bmalloc(SOCK_THREAD_STACK_SIZE);

      if (tcp_client_main_workthread_stack == NULL)
      {
        GINA_UWLOG_INFO("COM Client Workthread stack alloc failed");
        break;
      }

      GINA_UWLOG_INFO("COM Client Workthread threadp=%p stackp=%p",
                      tcp_client_main_workthread_hndl,
                      tcp_client_main_workthread_stack);

      /** run the test */
      status = tx_thread_create(tcp_client_main_workthread_hndl,
                                "COM Client Workthread",
                                tcp_client_main_workthread,
                                (void *)netctrl_dss_handle,
                                tcp_client_main_workthread_stack,
                                SOCK_THREAD_STACK_SIZE,
                                SOCK_THREAD_PRIORITY,
                                SOCK_THREAD_PRIORITY,
                                TX_NO_TIME_SLICE,
                                TX_AUTO_START);

      if (status != TX_SUCCESS)
      {
        GINA_UWLOG_INFO("COM Client Workthread creation failed rc=%lu",
                        status);
        break;
      }
    }
    if (dss_event & NETCTRL_SIG_EVT_FINISHED_EVENT)
    {

      GINA_UWLOG_INFO("COM Client mainthread finished");
      break;
    }
    if (dss_event & NETCTRL_SIG_EVT_EXIT_EVENT)
    {
      GINA_UWLOG_INFO("NETCTRL_SIG_EVT_EXIT_EVENT Signal");
      break;
    }
  }

  if (tcp_client_main_workthread_hndl != NULL)
    while (TX_DELETE_ERROR == tx_thread_delete(
                                  tcp_client_main_workthread_hndl))
      qapi_Timer_Sleep(100, QAPI_TIMER_UNIT_MSEC, true);

  netctrl_stop();

  GINA_UWLOG_INFO("COM Client done");
  return 0;
}
