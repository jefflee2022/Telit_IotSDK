/******************************************************************************

 Copyright (C) 2021 THALES DIS AIS Deutschland GmbH

 This software is protected by international intellectual property laws and
 treaties. Customer shall not reverse engineer, decompile or disassemble the
 source code and shall only use the source code for the purpose of evaluation,
 analysis and to provide feedback thereon to Gemalto. Any right, title and
 interest in and to the source code, other than those expressly granted to the
 customer under this agreement, shall remain vested with Gemalto. This
 license may be terminated by Gemalto at any time in writing. Customer
 undertakes not to provide third parties with the source code. In particular,
 Customer is not allowed to sell, to lend or to license the source code or to
 make it available to the public.

 The information contained in this document is considered the CONFIDENTIAL and
 PROPRIETARY information of Gemalto M2M GmbH and may not be
 disclosed or discussed with anyone who is not employed by Gemalto M2M
 GmbH, unless the individual company:

 i)  has an express need to know such information, and

 ii) disclosure of information is subject to the terms of a duly executed
 Confidentiality  and Non-Disclosure Agreement between Gemalto M2M GmbH
 and the individual company.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 GEMALTO, ITS LEGAL REPRESENTATIVES AND VICARIOUS AGENTS SHALL - IRRESPECTIVE
 OF THE LEGAL GROUND - ONLY BE LIABLE FOR DAMAGES IF THE DAMAGE WAS CAUSED
 THROUGH CULPABLE BREACH OF A MAJOR CONTRACTUAL OBLIGATION (CARDINAL DUTY),
 I.E. A DUTY THE FULFILMENT OF WHICH ALLOWS THE PROPER EXECUTION OF THE
 RESPECTIVE AGREEMENT IN THE FIRST PLACE OR THE BREACH OF WHICH PUTS THE
 ACHIEVEMENT OF THE PURPOSE OF THE AGREEMENT AT STAKE, RESPECTIVELY, AND ON
 THE FULFILMENT OF WHICH THE RECIPIENT THEREFORE MAY RELY ON OR WAS CAUSED BY
 GROSS NEGLIGENCE OR INTENTIONALLY. ANY FURTHER LIABILITY FOR DAMAGES SHALL -
 IRRESPECTIVE OF THE LEGAL GROUND - BE EXCLUDED. IN THE EVENT THAT GEMALTO
 IS LIABLE FOR THE VIOLATION OF A MAJOR CONTRACTUAL OBLIGATION IN THE ABSENCE
 OF GROSS NEGLIGENCE OR WILFUL CONDUCT, SUCH LIABILITY FOR DAMAGE SHALL BE
 LIMITED TO AN EXTENT WHICH, AT THE TIME WHEN THE RESPECTIVE AGREEMENT IS
 CONCLUDED, GEMALTO SHOULD NORMALLY EXPECT TO ARISE DUE TO CIRCUMSTANCES THAT
 THE PARTIES HAD KNOWLEDGE OF AT SUCH POINT IN TIME. GEMALTO SHALL IN NO
 EVENT BE LIABLE FOR INDIRECT AND CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT.
 GEMALTO SHALL IN NO EVENT BE LIABLE FOR AN AMOUNT EXCEEDING EUR 20,000.00
 PER EVENT OF  DAMAGE. WITHIN THE BUSINESS RELATIONSHIP THE OVERALL LIABILITY
 SHALL BE  LIMITED TO A TOTAL OF EUR 100,000.00. CLAIMS FOR DAMAGES SHALL
 BECOME TIME-BARRED AFTER ONE YEAR AS OF THE BEGINNING OF THE STATUTORY
 LIMITATION PERIOD. IRRESPECTIVE OF THE LICENSEE'S KNOWLEDGE OR GROSS NEGLIGENT
 LACK OF  KNOWLEDGE OF THE CIRCUMSTANCES GIVING RISE FOR A LIABILITY ANY CLAIMS
 SHALL BECOME TIME-BARRED AFTER FIVE YEARS AS OF THE LIABILITY AROSE. THE
 AFOREMENTIONED LIMITATION OR EXCLUSION OF LIABILITY SHALL NOT APPLY IN THE
 CASE OF CULPABLE INJURY TO LIFE, BODY OR HEALTH, IN CASE OF INTENTIONAL ACTS,
 UNDER THE LIABILITY PROVISIONS OF THE GERMAN PRODUCT LIABILITY ACT
 (PRODUKTHAFTUNGSGESETZ) OR IN CASE OF A CONTRACTUALLY AGREED OBLIGATION TO
 ASSUME LIABILITY IRRESPECTIVE OF ANY FAULT (GUARANTEE).

 IN THE EVENT OF A CONFLICT BETWEEN THE PROVISIONS OF THIS AGREEMENT AND
 ANOTHER AGREEMENT REGARDING THE SOURCE CODE (EXCEPT THE GENERAL TERMS AND
 CONDITIONS OF GEMALTO) THE OTHER AGREEMENT SHALL PREVAIL.

 All rights created by patent grant or registration of a utility model or
 design patent are reserved.
******************************************************************************/

/**
 * @brief  A file access lib for ASC0 COM port to a TCP server application
 * @version 1.0
 * @author Antony Shen <antony.shen@thalesgroup.com>
 */

#include "file.h"

/* create a folder */
qapi_Status_t mkdir(char *pdir)
{
    struct qapi_FS_Stat_Type_s buf = {0};
    qapi_FS_Status_t qstat = QAPI_OK;

    if (!pdir)
        return QAPI_ERR_INVALID_PARAM;

    GINA_UWLOG_INFO("%s: Check if DIR: %s exist...", __func__, pdir);
    if (QAPI_ERR_NO_ENTRY == qapi_FS_Stat(pdir, &buf))
    {
        GINA_UWLOG_INFO("%s: DIR: %s doesn't exist, make one...", __func__, pdir);
        qstat = qapi_FS_Mk_Dir(pdir, QAPI_FS_O_CREAT_E | QAPI_FS_O_WRONLY_E);
        if (qstat != QAPI_OK)
        {
            GINA_UWLOG_ERROR("%s: Create %s Failed!!", __func__, pdir);
        }
        else
            GINA_UWLOG_INFO("%s: DIR: %s successfully created!", __func__, pdir);
    }
    else
        GINA_UWLOG_DBG("%s: DIR: %s already exist!", __func__, pdir);

end:
    return qstat;
}

/* delete a dir*/
qapi_Status_t rmdir(char *pdir)
{
    qapi_FS_Status_t qstat = qapi_FS_Rm_Dir(pdir);

    if (!pdir)
        return QAPI_ERR_INVALID_PARAM;

    qstat = qapi_FS_Rm_Dir(pdir);

    if (QAPI_OK == qstat)
        GINA_UWLOG_INFO("%s: rm %s successfully!", __func__, pdir);

    return qstat;
}

/* delete a file*/
qapi_Status_t rmfile(char *file)
{
    qapi_FS_Status_t qstat;

    if (!file)
        return QAPI_ERR_INVALID_PARAM;

    GINA_UWLOG_INFO("%s: rm %s ...", __func__, file);

    qstat = qapi_FS_Unlink(file);

    if (QAPI_OK != qstat)
        GINA_UWLOG_ERROR("%s: rm %s with error: %ld!", __func__, file, qstat);

    return qstat;
}

int open_file(char *file)
{
    int fd = -1;
    qapi_FS_Status_t qstat;

    if (file)
    {
        qstat = qapi_FS_Open(file, QAPI_FS_O_RDWR_E | QAPI_FS_O_CREAT_E, &fd);

        if (qstat != QAPI_OK)
            GINA_UWLOG_ERROR("%s: ERROR: open %s failed", __func__, file);
    }

end:
    return fd;
}

int get_file_size(char *file)
{
    struct qapi_FS_Stat_Type_s stat_buf = {0};
    qapi_FS_Status_t qstat = qapi_FS_Stat(file, &stat_buf);
    if (QAPI_OK != qstat)
    {
        GINA_UWLOG_ERROR("%s: qapi_FS_Stat on %s FAILED!!", __func__, file);
        return -1;
    }
    return stat_buf.st_size;
}

int file_exist(char *file)
{
    struct qapi_FS_Stat_Type_s buf = {0};
    qapi_FS_Status_t qstat = QAPI_OK;
    int rc = FALSE;

    if (!file)
        goto end;

    if (QAPI_ERR_NO_ENTRY != qapi_FS_Stat(file, &buf))
        rc = TRUE;

end:
    return rc;
}

int write_file(int fd, char *buf, int size)
{
    int len = -1;
    qapi_FS_Status_t ret;

    if ((fd != -1) && buf && (size > 0))
    {
        ret = qapi_FS_Write(fd, buf, size, &len);
        if (len != size)
            GINA_UWLOG_DBG("%s: Fuck!! size=%d and written len=%d!!", __func__, size, len);
        if (ret != QAPI_OK)
            GINA_UWLOG_DBG("%s: Fuck!! Write failed!!", __func__);
    }

    return len;
}


int read_file(int fd, char *buf, int size)
{
    int len = -1;
    qapi_FS_Status_t ret;

    if ((fd != -1) && buf && (size > 0))
    {
        ret = qapi_FS_Read(fd, buf, size, &len);
        GINA_UWLOG_DBG("%s: size=%d and read len=%d!!", __func__, size, len);
        if (ret != QAPI_OK)
            GINA_UWLOG_DBG("%s: Fuck!! Read failed!!", __func__);
    }

    return len;
}