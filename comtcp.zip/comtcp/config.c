/******************************************************************************

 Copyright (C) 2021 THALES DIS AIS Deutschland GmbH

 This software is protected by international intellectual property laws and
 treaties. Customer shall not reverse engineer, decompile or disassemble the
 source code and shall only use the source code for the purpose of evaluation,
 analysis and to provide feedback thereon to Gemalto. Any right, title and
 interest in and to the source code, other than those expressly granted to the
 customer under this agreement, shall remain vested with Gemalto. This
 license may be terminated by Gemalto at any time in writing. Customer
 undertakes not to provide third parties with the source code. In particular,
 Customer is not allowed to sell, to lend or to license the source code or to
 make it available to the public.

 The information contained in this document is considered the CONFIDENTIAL and
 PROPRIETARY information of Gemalto M2M GmbH and may not be
 disclosed or discussed with anyone who is not employed by Gemalto M2M
 GmbH, unless the individual company:

 i)  has an express need to know such information, and

 ii) disclosure of information is subject to the terms of a duly executed
 Confidentiality  and Non-Disclosure Agreement between Gemalto M2M GmbH
 and the individual company.

 THIS CODE AND INFORMATION IS PROVIDED "AS IS" WITHOUT WARRANTY OF ANY KIND,
 EITHER EXPRESSED OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED
 WARRANTIES OF MERCHANTABILITY AND/OR FITNESS FOR A PARTICULAR PURPOSE.
 GEMALTO, ITS LEGAL REPRESENTATIVES AND VICARIOUS AGENTS SHALL - IRRESPECTIVE
 OF THE LEGAL GROUND - ONLY BE LIABLE FOR DAMAGES IF THE DAMAGE WAS CAUSED
 THROUGH CULPABLE BREACH OF A MAJOR CONTRACTUAL OBLIGATION (CARDINAL DUTY),
 I.E. A DUTY THE FULFILMENT OF WHICH ALLOWS THE PROPER EXECUTION OF THE
 RESPECTIVE AGREEMENT IN THE FIRST PLACE OR THE BREACH OF WHICH PUTS THE
 ACHIEVEMENT OF THE PURPOSE OF THE AGREEMENT AT STAKE, RESPECTIVELY, AND ON
 THE FULFILMENT OF WHICH THE RECIPIENT THEREFORE MAY RELY ON OR WAS CAUSED BY
 GROSS NEGLIGENCE OR INTENTIONALLY. ANY FURTHER LIABILITY FOR DAMAGES SHALL -
 IRRESPECTIVE OF THE LEGAL GROUND - BE EXCLUDED. IN THE EVENT THAT GEMALTO
 IS LIABLE FOR THE VIOLATION OF A MAJOR CONTRACTUAL OBLIGATION IN THE ABSENCE
 OF GROSS NEGLIGENCE OR WILFUL CONDUCT, SUCH LIABILITY FOR DAMAGE SHALL BE
 LIMITED TO AN EXTENT WHICH, AT THE TIME WHEN THE RESPECTIVE AGREEMENT IS
 CONCLUDED, GEMALTO SHOULD NORMALLY EXPECT TO ARISE DUE TO CIRCUMSTANCES THAT
 THE PARTIES HAD KNOWLEDGE OF AT SUCH POINT IN TIME. GEMALTO SHALL IN NO
 EVENT BE LIABLE FOR INDIRECT AND CONSEQUENTIAL DAMAGES OR LOSS OF PROFIT.
 GEMALTO SHALL IN NO EVENT BE LIABLE FOR AN AMOUNT EXCEEDING EUR 20,000.00
 PER EVENT OF  DAMAGE. WITHIN THE BUSINESS RELATIONSHIP THE OVERALL LIABILITY
 SHALL BE  LIMITED TO A TOTAL OF EUR 100,000.00. CLAIMS FOR DAMAGES SHALL
 BECOME TIME-BARRED AFTER ONE YEAR AS OF THE BEGINNING OF THE STATUTORY
 LIMITATION PERIOD. IRRESPECTIVE OF THE LICENSEE'S KNOWLEDGE OR GROSS NEGLIGENT
 LACK OF  KNOWLEDGE OF THE CIRCUMSTANCES GIVING RISE FOR A LIABILITY ANY CLAIMS
 SHALL BECOME TIME-BARRED AFTER FIVE YEARS AS OF THE LIABILITY AROSE. THE
 AFOREMENTIONED LIMITATION OR EXCLUSION OF LIABILITY SHALL NOT APPLY IN THE
 CASE OF CULPABLE INJURY TO LIFE, BODY OR HEALTH, IN CASE OF INTENTIONAL ACTS,
 UNDER THE LIABILITY PROVISIONS OF THE GERMAN PRODUCT LIABILITY ACT
 (PRODUKTHAFTUNGSGESETZ) OR IN CASE OF A CONTRACTUALLY AGREED OBLIGATION TO
 ASSUME LIABILITY IRRESPECTIVE OF ANY FAULT (GUARANTEE).

 IN THE EVENT OF A CONFLICT BETWEEN THE PROVISIONS OF THIS AGREEMENT AND
 ANOTHER AGREEMENT REGARDING THE SOURCE CODE (EXCEPT THE GENERAL TERMS AND
 CONDITIONS OF GEMALTO) THE OTHER AGREEMENT SHALL PREVAIL.

 All rights created by patent grant or registration of a utility model or
 design patent are reserved.
******************************************************************************/

/**
 * @brief  A configuration file access lib for ASC0 COM port to a TCP server application
 * @version 1.0
 * @author Antony Shen <antony.shen@thalesgroup.com>
 */

#include "config.h"

//~ no working strdup in this SDK!!
static char *strdup_(const char *s)
{
    int len;
    char *ptr = NULL;

    if (s)
    {
        len = strlen(s) + 1;
        ptr = bmalloc(len);

        if (ptr)
            memcpy(ptr, s, len);
        else GINA_UWLOG_ERROR("%s: mem allocation failed!!", __func__);
    } else GINA_UWLOG_DBG("%s: source str is NULL!!", __func__);

end:
    return ptr;
}

static int handler(void *user, const char *section, const char *name, const char *value)
{
    configuration *pconfig = (configuration *)user;

#define MATCH(s, n) strcmp(section, s) == 0 && strcmp(name, n) == 0

    if (MATCH(SEC_SERIAL, ITEM_BAUD))
    {
        pconfig->baud = atoi(value);
    }
    else if (MATCH(SEC_SERVER, ITEM_IP))
    {
        pconfig->tcp_server_ip = strdup_(value);
    }
    else if (MATCH(SEC_SERVER, ITEM_PORT))
    {
        pconfig->tcp_server_port = atoi(value);
    }
    else if (MATCH(SEC_CELLULAR, ITEM_APN))
    {
        pconfig->apn = strdup_(value);
    }
    else if (MATCH(SEC_CELLULAR, ITEM_CID))
    {
        pconfig->apn_cid = atoi(value);
    }
    else if (MATCH(SEC_CELLULAR, ITEM_USERNAME))
    {
        pconfig->apn_username = strdup_(value);
    }
    else if (MATCH(SEC_CELLULAR, ITEM_PASSWORD))
    {
        pconfig->apn_passwd = strdup_(value);
    }
    else
    {
        return FALSE; /* unknown section/name, error */
    }
    return TRUE;
}

char *read_ini_file(char *fname)
{
    int fd, i, len = -1;
    char *ptr = NULL;

    i = get_file_size(fname);
    if (i == -1)
        goto end;
    GINA_UWLOG_DBG("%s: file: %s exist / size: %d ==\n", __func__, fname, i);

    ptr = bmalloc(i);
    if (ptr)
    {
        fd = open_file(fname);
        if (fd != -1)
        {
            len = read_file(fd, ptr, i);
            GINA_UWLOG_DBG("%s: read size: %d ==\n", __func__, len);

            closefile(fd);
        }
    }
end:
    return ptr;
}

int create_ini_file(char *fname)
{
    int fd = -1;
    int rc = FALSE;
    int len, i;
#define SIZE_BUF 1024
    char *pbuf = bmalloc(SIZE_BUF);
    char *ptr;

    if (!pbuf)
        goto end;
    len = SIZE_BUF;
    ptr = pbuf;

    fd = open_file(fname);
    if (fd == -1)
        goto end;

    i = snprintf(pbuf, len, "[%s]\n", SEC_SERIAL);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n\r\n", ITEM_BAUD, SER_BAUDRATE);

    i = snprintf(ptr += i, len -= i, "[%s]\r\n", SEC_SERVER);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n", ITEM_IP, NET_TCP_SERVER_IP);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n\r\n", ITEM_PORT, NET_TCP_SERVER_PORT);

    i = snprintf(ptr += i, len -= i, "[%s]\r\n", SEC_CELLULAR);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n", ITEM_APN, NET_APN);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n", ITEM_CID, NET_APN_CID);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n", ITEM_USERNAME, NET_USERNAME);
    i = snprintf(ptr += i, len -= i, "%s=%s\r\n\r\n", ITEM_PASSWORD, NET_PASSWORD);

    GINA_UWLOG_DBG("ini data len = %d\n", SIZE_BUF - len - i);
    GINA_UWLOG_DBG("%s", pbuf);

    write_file(fd, pbuf, SIZE_BUF - len - i);

cleanup:
    closefile(fd);
    bfree(pbuf);

    rc = TRUE;

end:
    return rc;
}

configuration *get_config(char *fname)
{
    configuration *pconfig = NULL;
    char *ptr;
    int len;

    if (!fname)
        goto end;

    ptr = read_ini_file(fname);

    if (ptr)
    {
        pconfig = bmalloc(sizeof(configuration));

        if (pconfig)
        {
            if (ini_parse_string(ptr, handler, pconfig) < 0)
            {
                GINA_UWLOG_ERROR("Can't parse string\n");
            }

            bfree(ptr);
        }
    }

end:
    return pconfig;
}